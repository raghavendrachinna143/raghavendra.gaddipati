package com.newbie.average.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.newbie.average.model.Country;

public class ReadFiles {

	public List<Country> readCountriesData(File file) throws FileNotFoundException {

		List<Country> countries = new ArrayList<>();

		String line = "";
		String splitBy = ";";
		try {
			// parsing a CSV file into BufferedReader class constructor
			BufferedReader br = new BufferedReader(new FileReader(file));
			int skip = 0;
			while ((line = br.readLine()) != null) {
				if (skip > 1) {
					String[] country = line.split(splitBy); // use comma as separator
					Country createCountry = createCountry(country);
					System.out.println(createCountry);
					countries.add(createCountry);
				}
				skip++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return countries;
	}

	private Country createCountry(String[] metaData) {
		List<String> list = Arrays.asList(metaData);
		Country country = new Country();
		if (list.size() > 0) {
			country.setCountry(list.get(0));
		}
		if (list.size() > 1) {
			country.setArea(convertDouble(list.get(1)));
		}
		if (list.size() > 2) {
			country.setBirthRate(convertDouble(list.get(2)));
		}
		if (list.size() > 3) {
			country.setCurrentAccountBalance(convertDouble(list.get(3)));
		}
		if (list.size() > 4) {
			country.setDeathRate(convertDouble(list.get(4)));
		}
		if (list.size() > 5) {
			country.setDebtExternal(convertDouble(list.get(5)));
		}
		if (list.size() > 6) {
			country.setElectricityConsumption(convertDouble(list.get(6)));
		}
		if (list.size() > 7) {
			country.setElectricityProduction(convertDouble(list.get(7)));
		}
		if (list.size() > 8) {
			country.setExports(convertDouble(list.get(8)));
		}
		if (list.size() > 9) {
			country.setGdp(convertDouble(list.get(9)));
		}
		if (list.size() > 10) {
			country.setGdpPerCapita(convertDouble(list.get(10)));
		}
		if (list.size() > 11) {
			country.setGdpRealGrowthRate(convertDouble(list.get(11)));
		}
		if (list.size() > 12) {
			country.setHivAidsAdultPrevalenceRate(convertDouble(list.get(12)));
		}
		if (list.size() > 13) {
			country.setHivAidsDeaths(convertDouble(list.get(13)));
		}
		if (list.size() > 14) {
			country.setHivAidsPeopleLiving(convertDouble(list.get(14)));
		}
		if (list.size() > 15) {
			country.setHighways(convertDouble(list.get(15)));
		}
		if (list.size() > 16) {
			country.setImports(convertDouble(list.get(16)));
		}
		if (list.size() > 17) {
			country.setIndustrialProductionRateGrowth(convertDouble(list.get(17)));
		}
		if (list.size() > 18) {
			country.setInfantMortalityRate(convertDouble(list.get(18)));
		}
		if (list.size() > 19) {
			country.setInflationRate(convertDouble(list.get(19)));
		}
		if (list.size() > 20) {
			country.setInternetHosts(convertDouble(list.get(20)));
		}
		if (list.size() > 21) {
			country.setInternetUsers(convertDouble(list.get(21)));
		}
		if (list.size() > 22) {
			country.setInvestment(convertDouble(list.get(22)));
		}
		if (list.size() > 23) {
			country.setLaborForce(convertDouble(list.get(23)));
		}
		if (list.size() > 24) {
			country.setLifeExpectancyAtBirth(convertDouble(list.get(24)));
		}
		if (list.size() > 25) {
			country.setMilitaryExpendituresDollarFigure(convertDouble(list.get(25)));
		}
		if (list.size() > 26) {
			country.setMilitaryExpenditurePercentOfGDP(convertDouble(list.get(26)));
		}
		if (list.size() > 27) {
			country.setNaturalgasConsumption(convertDouble(list.get(27)));
		}
		if (list.size() > 28) {
			country.setNaturalgasExports(convertDouble(list.get(28)));
		}
		if (list.size() > 29) {
			country.setNaturalgasImports(convertDouble(list.get(29)));
		}
		if (list.size() > 30) {
			country.setNaturalgasProduction(convertDouble(list.get(30)));
		}
		if (list.size() > 31) {
			country.setNaturalgasProvedReserves(convertDouble(list.get(31)));
		}
		if (list.size() > 32) {
			country.setOilConsumption(convertDouble(list.get(32)));
		}
		if (list.size() > 33) {
			country.setOilExports(convertDouble(list.get(33)));
		}
		if (list.size() > 34) {
			country.setOilImports(convertDouble(list.get(34)));
		}
		if (list.size() > 35) {
			country.setOilProduction(convertDouble(list.get(35)));
		}
		if (list.size() > 36) {
			country.setOilProvedReserves(convertDouble(list.get(36)));
		}
		if (list.size() > 37) {
			country.setPopulation(convertDouble(list.get(37)));
		}
		if (list.size() > 38) {
			country.setPublicDebt(convertDouble(list.get(38)));
		}
		if (list.size() > 39) {
			country.setRailways(convertDouble(list.get(39)));
		}
		if (list.size() > 40) {
			country.setReservesOfForeignExchangeGold(convertDouble(list.get(40)));
		}
		if (list.size() > 41) {
			country.setTelephonesMainLines(convertDouble(list.get(41)));
		}
		if (list.size() > 42) {
			country.setTelephonesMobileCellular(convertDouble(list.get(42)));
		}
		if (list.size() > 43) {
			country.setTotalFertilityRate(convertDouble(list.get(43)));
		}
		if (list.size() > 44) {
			country.setUnemploymentRate(convertDouble(list.get(44)));
		}
		return country;
	}

	private Double convertDouble(String value) {
		if (value != null && value != "") {
			return Double.parseDouble(value);
		}
		return 0.0;
	}
}
