package com.newbie.average.utils;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import com.newbie.average.model.Country;

public class WriteFiles {

	public void writeData(List<Country> list, String filePath) throws IOException {
		FileWriter writer = new FileWriter(filePath);
		for (Country s : list) {
			String countryStr = getCountryStr(s);
			writer.write(countryStr);
			writer.write("\n"); // newline
		}

		writer.close();
	}

	private String getCountryStr(Country country) {
		return country.getCountry() + ";" + country.getArea() + ";" + country.getBirthRate() + ";"
				+ country.getCurrentAccountBalance() + ";" + country.getDeathRate() + ";" + country.getDebtExternal()
				+ ";" + country.getElectricityConsumption() + ";" + country.getElectricityProduction() + ";"
				+ country.getExports() + ";" + country.getGdp() + ";" + country.getGdpPerCapita() + ";"
				+ country.getGdpRealGrowthRate() + ";" + country.getHivAidsAdultPrevalenceRate() + ";"
				+ country.getHivAidsDeaths() + ";" + country.getHivAidsPeopleLiving() + ";" + country.getHighways()
				+ ";" + country.getImports() + ";" + country.getIndustrialProductionRateGrowth() + ";"
				+ country.getInfantMortalityRate() + ";" + country.getInflationRate() + ";" + country.getInternetHosts()
				+ ";" + country.getInternetUsers() + ";" + country.getInvestment() + ";" + country.getLaborForce() + ";"
				+ country.getLifeExpectancyAtBirth() + ";" + country.getMilitaryExpendituresDollarFigure() + ";"
				+ country.getMilitaryExpenditurePercentOfGDP() + ";" + country.getNaturalgasConsumption() + ";"
				+ country.getNaturalgasExports() + ";" + country.getNaturalgasImports() + ";"
				+ country.getNaturalgasProduction() + ";" + country.getNaturalgasProvedReserves() + ";"
				+ country.getOilConsumption() + ";" + country.getOilExports() + ";" + country.getOilImports() + ";"
				+ country.getOilProduction() + ";" + country.getOilProvedReserves() + ";" + country.getPopulation()
				+ ";" + country.getPublicDebt() + ";" + country.getRailways() + ";"
				+ country.getReservesOfForeignExchangeGold() + ";" + country.getTelephonesMainLines() + ";"
				+ country.getTelephonesMobileCellular() + ";" + country.getTotalFertilityRate() + ";"
				+ country.getUnemploymentRate();
	}
}
