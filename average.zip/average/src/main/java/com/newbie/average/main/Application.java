package com.newbie.average.main;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.newbie.average.model.Country;
import com.newbie.average.utils.AverageUtil;
import com.newbie.average.utils.ReadFiles;
import com.newbie.average.utils.WriteFiles;

public class Application {

	public static void main(String[] args) throws FileNotFoundException {
		final File folder = new File("C:\\Users\\sures\\new-bie-1\\average\\data");
		listFilesForFolder(folder);
	}

	public static void listFilesForFolder(final File folder) throws FileNotFoundException {
		List<Country> mergeList = new ArrayList<>();
		ReadFiles readFiles = new ReadFiles();
		WriteFiles writeFiles = new WriteFiles();
		
		for (final File fileEntry : folder.listFiles()) {
			if (fileEntry.isDirectory()) {
				listFilesForFolder(fileEntry);
			} else {
				System.out.println("------------------STRAT------------ " + fileEntry.getName()
						+ " -------------STRAT-------------");
				List<Country> readCountriesData = readFiles.readCountriesData(fileEntry);
				System.out.println(readCountriesData);
				System.out.println("--------------------END---------- " + fileEntry.getName()
						+ " ---------------END-------COUNT----" + readCountriesData.size());
				mergeList = merge(mergeList, readCountriesData);
			}
			System.out.println(
					"--------------------MERGE----------  ---------------END-------COUNT----" + mergeList.size());
			
			try {
				System.out.println(
						"--------------------WRITING------TEMP.CSV----");
				writeFiles.writeData(mergeList, "C:\\Users\\sures\\new-bie-1\\average\\temp.csv");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(
					"--------------------END--TEMP.CSV--------");
			
			System.out.println(
					"--------------------AVERGAE----------");
			
			try {			
				AverageUtil averageUtil = new AverageUtil();
				final File tempFile = new File("C:\\Users\\sures\\new-bie-1\\average\\temp.csv");
				List<Country> readCountriesData = readFiles.readCountriesData(tempFile);
				Country country = averageUtil.averageCountries(readCountriesData);				
				List<Country> averageList=new ArrayList<>();
				averageList.add(country);
				System.out.println(
						"--------------------WRITING------TEMP.CSV----");
				writeFiles.writeData(averageList, "C:\\Users\\sures\\new-bie-1\\average\\output\\output.csv");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(
					"--------------------END--AVERGAE.CSV--------");

		}
	}

	public static List<Country> merge(List<Country> list1, List<Country> list2) {
		List<Country> collect = Stream.of(list1, list2).flatMap(List::stream).distinct().collect(Collectors.toList());
		return collect;
	}
}
