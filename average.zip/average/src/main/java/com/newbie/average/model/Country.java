package com.newbie.average.model;

public class Country {
	private String country;
	private Double area;
	private Double birthRate;
	private Double currentAccountBalance;
	private Double deathRate;
	private Double debtExternal;
	private Double electricityConsumption;
	private Double electricityProduction;
	private Double exports;
	private Double gdp;
	private Double gdpPerCapita;
	private Double gdpRealGrowthRate;
	private Double hivAidsAdultPrevalenceRate;
	private Double hivAidsDeaths;
	private Double hivAidsPeopleLiving;
	private Double highways;
	private Double imports;
	private Double industrialProductionRateGrowth;
	private Double infantMortalityRate;
	private Double inflationRate;
	private Double internetHosts;
	private Double internetUsers;
	private Double investment;
	private Double laborForce;
	private Double lifeExpectancyAtBirth;
	private Double militaryExpendituresDollarFigure;
	private Double militaryExpenditurePercentOfGDP;
	private Double naturalgasConsumption;
	private Double naturalgasExports;
	private Double naturalgasImports;
	private Double naturalgasProduction;
	private Double naturalgasProvedReserves;
	private Double oilConsumption;
	private Double oilExports;
	private Double oilImports;
	private Double oilProduction;
	private Double oilProvedReserves;
	private Double population;
	private Double publicDebt;
	private Double railways;
	private Double reservesOfForeignExchangeGold;
	private Double telephonesMainLines;
	private Double telephonesMobileCellular;
	private Double totalFertilityRate;
	private Double unemploymentRate;

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Double getArea() {
		return area;
	}

	public void setArea(Double area) {
		this.area = area;
	}

	public Double getBirthRate() {
		return birthRate;
	}

	public void setBirthRate(Double birthRate) {
		this.birthRate = birthRate;
	}

	public Double getCurrentAccountBalance() {
		return currentAccountBalance;
	}

	public void setCurrentAccountBalance(Double currentAccountBalance) {
		this.currentAccountBalance = currentAccountBalance;
	}

	public Double getDeathRate() {
		return deathRate;
	}

	public void setDeathRate(Double deathRate) {
		this.deathRate = deathRate;
	}

	public Double getDebtExternal() {
		return debtExternal;
	}

	public void setDebtExternal(Double debtExternal) {
		this.debtExternal = debtExternal;
	}

	public Double getElectricityConsumption() {
		return electricityConsumption;
	}

	public void setElectricityConsumption(Double electricityConsumption) {
		this.electricityConsumption = electricityConsumption;
	}

	public Double getElectricityProduction() {
		return electricityProduction;
	}

	public void setElectricityProduction(Double electricityProduction) {
		this.electricityProduction = electricityProduction;
	}

	public Double getExports() {
		return exports;
	}

	public void setExports(Double exports) {
		this.exports = exports;
	}

	public Double getGdp() {
		return gdp;
	}

	public void setGdp(Double gdp) {
		this.gdp = gdp;
	}

	public Double getGdpPerCapita() {
		return gdpPerCapita;
	}

	public void setGdpPerCapita(Double gdpPerCapita) {
		this.gdpPerCapita = gdpPerCapita;
	}

	public Double getGdpRealGrowthRate() {
		return gdpRealGrowthRate;
	}

	public void setGdpRealGrowthRate(Double gdpRealGrowthRate) {
		this.gdpRealGrowthRate = gdpRealGrowthRate;
	}

	public Double getHivAidsAdultPrevalenceRate() {
		return hivAidsAdultPrevalenceRate;
	}

	public void setHivAidsAdultPrevalenceRate(Double hivAidsAdultPrevalenceRate) {
		this.hivAidsAdultPrevalenceRate = hivAidsAdultPrevalenceRate;
	}

	public Double getHivAidsDeaths() {
		return hivAidsDeaths;
	}

	public void setHivAidsDeaths(Double hivAidsDeaths) {
		this.hivAidsDeaths = hivAidsDeaths;
	}

	public Double getHivAidsPeopleLiving() {
		return hivAidsPeopleLiving;
	}

	public void setHivAidsPeopleLiving(Double hivAidsPeopleLiving) {
		this.hivAidsPeopleLiving = hivAidsPeopleLiving;
	}

	public Double getHighways() {
		return highways;
	}

	public void setHighways(Double highways) {
		this.highways = highways;
	}

	public Double getImports() {
		return imports;
	}

	public void setImports(Double imports) {
		this.imports = imports;
	}

	public Double getIndustrialProductionRateGrowth() {
		return industrialProductionRateGrowth;
	}

	public void setIndustrialProductionRateGrowth(Double industrialProductionRateGrowth) {
		this.industrialProductionRateGrowth = industrialProductionRateGrowth;
	}

	public Double getInfantMortalityRate() {
		return infantMortalityRate;
	}

	public void setInfantMortalityRate(Double infantMortalityRate) {
		this.infantMortalityRate = infantMortalityRate;
	}

	public Double getInflationRate() {
		return inflationRate;
	}

	public void setInflationRate(Double inflationRate) {
		this.inflationRate = inflationRate;
	}

	public Double getInternetHosts() {
		return internetHosts;
	}

	public void setInternetHosts(Double internetHosts) {
		this.internetHosts = internetHosts;
	}

	public Double getInternetUsers() {
		return internetUsers;
	}

	public void setInternetUsers(Double internetUsers) {
		this.internetUsers = internetUsers;
	}

	public Double getInvestment() {
		return investment;
	}

	public void setInvestment(Double investment) {
		this.investment = investment;
	}

	public Double getLaborForce() {
		return laborForce;
	}

	public void setLaborForce(Double laborForce) {
		this.laborForce = laborForce;
	}

	public Double getLifeExpectancyAtBirth() {
		return lifeExpectancyAtBirth;
	}

	public void setLifeExpectancyAtBirth(Double lifeExpectancyAtBirth) {
		this.lifeExpectancyAtBirth = lifeExpectancyAtBirth;
	}

	public Double getMilitaryExpendituresDollarFigure() {
		return militaryExpendituresDollarFigure;
	}

	public void setMilitaryExpendituresDollarFigure(Double militaryExpendituresDollarFigure) {
		this.militaryExpendituresDollarFigure = militaryExpendituresDollarFigure;
	}

	public Double getMilitaryExpenditurePercentOfGDP() {
		return militaryExpenditurePercentOfGDP;
	}

	public void setMilitaryExpenditurePercentOfGDP(Double militaryExpenditurePercentOfGDP) {
		this.militaryExpenditurePercentOfGDP = militaryExpenditurePercentOfGDP;
	}

	public Double getNaturalgasConsumption() {
		return naturalgasConsumption;
	}

	public void setNaturalgasConsumption(Double naturalgasConsumption) {
		this.naturalgasConsumption = naturalgasConsumption;
	}

	public Double getNaturalgasExports() {
		return naturalgasExports;
	}

	public void setNaturalgasExports(Double naturalgasExports) {
		this.naturalgasExports = naturalgasExports;
	}

	public Double getNaturalgasImports() {
		return naturalgasImports;
	}

	public void setNaturalgasImports(Double naturalgasImports) {
		this.naturalgasImports = naturalgasImports;
	}

	public Double getNaturalgasProduction() {
		return naturalgasProduction;
	}

	public void setNaturalgasProduction(Double naturalgasProduction) {
		this.naturalgasProduction = naturalgasProduction;
	}

	public Double getNaturalgasProvedReserves() {
		return naturalgasProvedReserves;
	}

	public void setNaturalgasProvedReserves(Double naturalgasProvedReserves) {
		this.naturalgasProvedReserves = naturalgasProvedReserves;
	}

	public Double getOilConsumption() {
		return oilConsumption;
	}

	public void setOilConsumption(Double oilConsumption) {
		this.oilConsumption = oilConsumption;
	}

	public Double getOilExports() {
		return oilExports;
	}

	public void setOilExports(Double oilExports) {
		this.oilExports = oilExports;
	}

	public Double getOilImports() {
		return oilImports;
	}

	public void setOilImports(Double oilImports) {
		this.oilImports = oilImports;
	}

	public Double getOilProduction() {
		return oilProduction;
	}

	public void setOilProduction(Double oilProduction) {
		this.oilProduction = oilProduction;
	}

	public Double getOilProvedReserves() {
		return oilProvedReserves;
	}

	public void setOilProvedReserves(Double oilProvedReserves) {
		this.oilProvedReserves = oilProvedReserves;
	}

	public Double getPopulation() {
		return population;
	}

	public void setPopulation(Double population) {
		this.population = population;
	}

	public Double getPublicDebt() {
		return publicDebt;
	}

	public void setPublicDebt(Double publicDebt) {
		this.publicDebt = publicDebt;
	}

	public Double getRailways() {
		return railways;
	}

	public void setRailways(Double railways) {
		this.railways = railways;
	}

	public Double getReservesOfForeignExchangeGold() {
		return reservesOfForeignExchangeGold;
	}

	public void setReservesOfForeignExchangeGold(Double reservesOfForeignExchangeGold) {
		this.reservesOfForeignExchangeGold = reservesOfForeignExchangeGold;
	}

	public Double getTelephonesMainLines() {
		return telephonesMainLines;
	}

	public void setTelephonesMainLines(Double telephonesMainLines) {
		this.telephonesMainLines = telephonesMainLines;
	}

	public Double getTelephonesMobileCellular() {
		return telephonesMobileCellular;
	}

	public void setTelephonesMobileCellular(Double telephonesMobileCellular) {
		this.telephonesMobileCellular = telephonesMobileCellular;
	}

	public Double getTotalFertilityRate() {
		return totalFertilityRate;
	}

	public void setTotalFertilityRate(Double totalFertilityRate) {
		this.totalFertilityRate = totalFertilityRate;
	}

	public Double getUnemploymentRate() {
		return unemploymentRate;
	}

	public void setUnemploymentRate(Double unemploymentRate) {
		this.unemploymentRate = unemploymentRate;
	}

	@Override
	public String toString() {
		return "Country [country=" + country + ", area=" + area + ", birthRate=" + birthRate
				+ ", currentAccountBalance=" + currentAccountBalance + ", deathRate=" + deathRate + ", debtExternal="
				+ debtExternal + ", electricityConsumption=" + electricityConsumption + ", electricityProduction="
				+ electricityProduction + ", exports=" + exports + ", gdp=" + gdp + ", gdpPerCapita=" + gdpPerCapita
				+ ", gdpRealGrowthRate=" + gdpRealGrowthRate + ", hivAidsAdultPrevalenceRate="
				+ hivAidsAdultPrevalenceRate + ", hivAidsDeaths=" + hivAidsDeaths + ", hivAidsPeopleLiving="
				+ hivAidsPeopleLiving + ", highways=" + highways + ", imports=" + imports
				+ ", industrialProductionRateGrowth=" + industrialProductionRateGrowth + ", infantMortalityRate="
				+ infantMortalityRate + ", inflationRate=" + inflationRate + ", internetHosts=" + internetHosts
				+ ", internetUsers=" + internetUsers + ", investment=" + investment + ", laborForce=" + laborForce
				+ ", lifeExpectancyAtBirth=" + lifeExpectancyAtBirth + ", militaryExpendituresDollarFigure="
				+ militaryExpendituresDollarFigure + ", militaryExpenditurePercentOfGDP="
				+ militaryExpenditurePercentOfGDP + ", naturalgasConsumption=" + naturalgasConsumption
				+ ", naturalgasExports=" + naturalgasExports + ", naturalgasImports=" + naturalgasImports
				+ ", naturalgasProduction=" + naturalgasProduction + ", naturalgasProvedReserves="
				+ naturalgasProvedReserves + ", oilConsumption=" + oilConsumption + ", oilExports=" + oilExports
				+ ", oilImports=" + oilImports + ", oilProduction=" + oilProduction + ", oilProvedReserves="
				+ oilProvedReserves + ", population=" + population + ", publicDebt=" + publicDebt + ", railways="
				+ railways + ", reservesOfForeignExchangeGold=" + reservesOfForeignExchangeGold
				+ ", telephonesMainLines=" + telephonesMainLines + ", telephonesMobileCellular="
				+ telephonesMobileCellular + ", totalFertilityRate=" + totalFertilityRate + ", unemploymentRate="
				+ unemploymentRate + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((country == null) ? 0 : country.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Country other = (Country) obj;
		if (country == null) {
			if (other.country != null)
				return false;
		} else if (!country.equals(other.country))
			return false;
		return true;
	}
}
