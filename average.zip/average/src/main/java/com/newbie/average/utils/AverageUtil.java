package com.newbie.average.utils;

import java.util.List;

import com.newbie.average.model.Country;

public class AverageUtil {
	public Country averageCountries(List<Country> countryList) {
		int size = countryList.size();
		Double area = 0.0;
		Double birthRate = 0.0;
		Double currentAccountBalance = 0.0;
		Double deathRate = 0.0;
		Double debtExternal = 0.0;
		Double electricityConsumption = 0.0;
		Double electricityProduction = 0.0;
		Double exports = 0.0;
		Double gdp = 0.0;
		Double gdpPerCapita = 0.0;
		Double gdpRealGrowthRate = 0.0;
		Double hivAidsAdultPrevalenceRate = 0.0;
		Double hivAidsDeaths = 0.0;
		Double hivAidsPeopleLiving = 0.0;
		Double highways = 0.0;
		Double imports = 0.0;
		Double industrialProductionRateGrowth = 0.0;
		Double infantMortalityRate = 0.0;
		Double inflationRate = 0.0;
		Double internetHosts = 0.0;
		Double internetUsers = 0.0;
		Double investment = 0.0;
		Double laborForce = 0.0;
		Double lifeExpectancyAtBirth = 0.0;
		Double militaryExpendituresDollarFigure = 0.0;
		Double militaryExpenditurePercentOfGDP = 0.0;
		Double naturalgasConsumption = 0.0;
		Double naturalgasExports = 0.0;
		Double naturalgasImports = 0.0;
		Double naturalgasProduction = 0.0;
		Double naturalgasProvedReserves = 0.0;
		Double oilConsumption = 0.0;
		Double oilExports = 0.0;
		Double oilImports = 0.0;
		Double oilProduction = 0.0;
		Double oilProvedReserves = 0.0;
		Double population = 0.0;
		Double publicDebt = 0.0;
		Double railways = 0.0;
		Double reservesOfForeignExchangeGold = 0.0;
		Double telephonesMainLines = 0.0;
		Double telephonesMobileCellular = 0.0;
		Double totalFertilityRate = 0.0;
		Double unemploymentRate = 0.0;

		for (Country c : countryList) {
			area = area + c.getArea();
			birthRate = birthRate + c.getBirthRate();
			currentAccountBalance = currentAccountBalance + c.getCurrentAccountBalance();
			deathRate = deathRate + c.getDeathRate();
			debtExternal = debtExternal + c.getDebtExternal();
			electricityConsumption = electricityConsumption + c.getElectricityConsumption();
			electricityProduction = electricityProduction + c.getElectricityProduction();
			exports = exports + c.getExports();
			gdp = gdp + c.getGdp();
			gdpPerCapita = gdpPerCapita + c.getGdpPerCapita();
			gdpRealGrowthRate = gdpRealGrowthRate + c.getGdpRealGrowthRate();
			hivAidsAdultPrevalenceRate = hivAidsAdultPrevalenceRate + c.getHivAidsAdultPrevalenceRate();
			hivAidsDeaths = hivAidsDeaths + c.getHivAidsDeaths();
			hivAidsPeopleLiving = hivAidsPeopleLiving + c.getHivAidsPeopleLiving();
			highways = highways + c.getHighways();
			imports = imports + c.getImports();
			industrialProductionRateGrowth = industrialProductionRateGrowth + c.getIndustrialProductionRateGrowth();
			infantMortalityRate = infantMortalityRate + c.getInfantMortalityRate();
			inflationRate = inflationRate + c.getInflationRate();
			internetHosts = internetHosts + c.getInternetHosts();
			internetUsers = internetUsers + c.getInternetUsers();
			investment = investment + c.getInvestment();
			laborForce = investment + c.getInvestment();
			lifeExpectancyAtBirth = lifeExpectancyAtBirth + c.getLifeExpectancyAtBirth();
			militaryExpendituresDollarFigure = militaryExpendituresDollarFigure
					+ c.getMilitaryExpendituresDollarFigure();
			militaryExpenditurePercentOfGDP = militaryExpenditurePercentOfGDP + c.getMilitaryExpenditurePercentOfGDP();
			naturalgasConsumption = naturalgasConsumption + c.getNaturalgasConsumption();
			naturalgasExports = naturalgasExports + c.getNaturalgasExports();
			naturalgasImports = naturalgasImports + c.getNaturalgasImports();
			naturalgasProduction = naturalgasProduction + c.getNaturalgasProduction();
			naturalgasProvedReserves = naturalgasProvedReserves + c.getNaturalgasProvedReserves();
			oilConsumption = oilConsumption + c.getOilConsumption();
			oilExports = oilExports + c.getOilExports();
			oilImports = oilImports + c.getOilImports();
			oilProduction = oilProduction + c.getOilProduction();
			oilProvedReserves = oilProvedReserves + c.getOilProvedReserves();
			population = population + c.getPopulation();
			publicDebt = publicDebt + c.getPublicDebt();
			railways = railways + c.getRailways();
			reservesOfForeignExchangeGold = reservesOfForeignExchangeGold + c.getReservesOfForeignExchangeGold();
			telephonesMainLines = telephonesMainLines + c.getTelephonesMainLines();
			telephonesMobileCellular = telephonesMobileCellular + c.getTelephonesMobileCellular();
			totalFertilityRate = totalFertilityRate + c.getTotalFertilityRate();
			unemploymentRate = unemploymentRate + c.getUnemploymentRate();

		}
		Country country = new Country();
		country.setCountry("AverageCountry");

		country.setArea(area / size);

		country.setBirthRate(birthRate / size);

		country.setCurrentAccountBalance(currentAccountBalance / size);

		country.setDeathRate(deathRate / size);

		country.setDebtExternal(debtExternal / size);

		country.setElectricityConsumption(electricityConsumption / size);

		country.setElectricityProduction(electricityProduction / size);

		country.setExports(exports / size);

		country.setGdp(gdp / size);

		country.setGdpPerCapita(gdpPerCapita / size);

		country.setGdpRealGrowthRate(gdpRealGrowthRate / size);

		country.setHivAidsAdultPrevalenceRate(hivAidsAdultPrevalenceRate / size);

		country.setHivAidsDeaths(hivAidsDeaths / size);

		country.setHivAidsPeopleLiving(hivAidsPeopleLiving / size);

		country.setHighways(highways / size);

		country.setImports(imports / size);

		country.setIndustrialProductionRateGrowth(industrialProductionRateGrowth / size);

		country.setInfantMortalityRate(infantMortalityRate / size);

		country.setInflationRate(inflationRate / size);

		country.setInternetHosts(internetHosts / size);

		country.setInternetUsers(internetUsers / size);

		country.setInvestment(investment / size);

		country.setLaborForce(laborForce / size);

		country.setLifeExpectancyAtBirth(lifeExpectancyAtBirth / size);

		country.setMilitaryExpendituresDollarFigure(militaryExpendituresDollarFigure / size);

		country.setMilitaryExpenditurePercentOfGDP(militaryExpenditurePercentOfGDP / size);

		country.setNaturalgasConsumption(naturalgasConsumption / size);
		country.setNaturalgasExports(naturalgasExports / size);

		country.setNaturalgasImports(naturalgasImports / size);

		country.setNaturalgasProduction(naturalgasProduction / size);

		country.setNaturalgasProvedReserves(naturalgasProvedReserves / size);

		country.setOilConsumption(oilConsumption / size);

		country.setOilExports(oilExports / size);

		country.setOilImports(oilImports / size);

		country.setOilProduction(oilProduction / size);

		country.setOilProvedReserves(oilProvedReserves / size);

		country.setPopulation(population / size);

		country.setPublicDebt(publicDebt / size);

		country.setRailways(railways / size);

		country.setReservesOfForeignExchangeGold(reservesOfForeignExchangeGold / size);

		country.setTelephonesMainLines(telephonesMainLines / size);

		country.setTelephonesMobileCellular(telephonesMobileCellular / size);

		country.setTotalFertilityRate(totalFertilityRate / size);

		country.setUnemploymentRate(unemploymentRate / size);

		return country;
	}
}
